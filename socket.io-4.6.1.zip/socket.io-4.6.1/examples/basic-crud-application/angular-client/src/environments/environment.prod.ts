export const environment = {
  production: true,
  serverUrl: "https://my-custom-domain.com"
};
